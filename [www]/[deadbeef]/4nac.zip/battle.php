<?
        function GetBattle($ID) {
                $sock = fsockopen("city1.timezero.ru", 80, $errno, $errstr, 5);
                if ($sock) {
                        fputs($sock, "GET /getbattle?id=".$ID." HTTP/1.0\r\n");
                        fputs($sock, "Host: city1.timezero.ru\r\n");
                        fputs($sock, "Content-type: application/x-www-url-encoded \r\nn");
                        fputs($sock, "Connection: Keep-Alive\r\n");
                        fputs($sock, "\r\n\r\n");
                        $tmp_headers = "";
                        $tmp_body = "";
                        while (!feof($sock)) {
                                $tmp_body .= fgets($sock, 4096);
                        }
                        return $tmp_body;
                        return 0;
                } else {
                        return 0;
                }
        }


//��� ������� �������� ��� ������� ����� � ����� ������ ��������, �� ����� ����� � ����� ����� �������

        function ParseBattle($Battle) {
                $Battle = iconv("UTF-8", "cp1251", $Battle);
                if (preg_match("/(^.*?\/BATTLE\>)(.*?\$)/", $Battle, $Head)) {
                        $Body = explode("</TURN><TURN>", $Head[2]);
                        $Head = $Head[1];
                        if (preg_match("/note=\"(.*?,.*?),(.*?)\"/", $Head, $Info)) {
                                $Location = $Info[1];
                                $BattleDate = date("Y-m-d", $Info[2]);
                                $BattleTime = date("H:i:s", $Info[2]);
                        }
                        if (preg_match("/battleid=\"(.*?)\"/", $Head, $ID)) {
                                $BattleID = $ID[1];
                        }
                        $Count = 0;
                        $MaxTeamNumber = 1;
                        $Users = array(); $Details = array();
                        while (preg_match("/.USER.*?login=\"(.*?)\".*?level=\"(.*?)\".*?HP=\"(.*?)\".*?side=\"(.*?)\".*?USER./", $Head, $User)) {
                                if (!preg_match("/\\\$/", $User[1])) {
                                        $Users[] = $User[1];
                                        $Details[$User[1]][] = $User[2];
                                        $Details[$User[1]][] = $User[4];
                                        $Details[$User[1]][] = '';
                                        $Details[$User[1]][] = '';
                                        $Details[$User[1]][] = '';
                                        if (preg_match("/clan=\"(.*?)\"/", $Head, $Clan)) {
                                                $Details[$User[1]][] = $Clan[1];
                                        } else $Details[$User[1]][] = '';
                                        $Details[$User[1]][] = $User[3];
                                        if ($MaxTeamNumber < $User[4]) {
                                                $MaxTeamNumber = $User[4];
                                        }
                                        $Count++;
                                }
                                $Head = preg_replace("/^.*?\/USER./", '', $Head);
                        }
                        $TurnsCount = 0; $DamageCount = 0;
                        foreach ($Body as $Turn) {
                                $TurnsCount++;
                                while (preg_match("/(.USER.*?\/USER.)/", $Turn, $Info)) {
                                        if (preg_match("/login=\"(.*?)\".*?level=\"(.*?)\".*?HP=\"(.*?)\".*?battleid.*?side=\"(.*?)\"/", $Info[1], $User)) {
                                                if (!preg_match("/\\\$/", $User[1])) {
                                                        $Users[] = $User[1];
                                                        $Details[$User[1]][] = $User[2];
                                                        $Details[$User[1]][] = $User[4];
                                                        $Details[$User[1]][] = $TurnsCount;
                                                        $Details[$User[1]][] = '';
                                                        $Details[$User[1]][] = '';
                                                        if (preg_match("/clan=\"(.*?)\"/", $Info[1], $Clan)) {
                                                                $Details[$User[1]][] = $Clan[1];
                                                        } else $Details[$User[1]][] = '';
                                                        $Details[$User[1]][] = $User[3];
                                                        if ($MaxTeamNumber < $User[4]) {
                                                                $MaxTeamNumber = $User[4];
                                                        }
                                                        $Count++;
                                                }
                                        } else {
                                                if (preg_match("/login=\"(.*?)\"/", $Info[1], $User)) {
                                                        if (!preg_match("/\\\$/", $User[1])) {
                                                                while (preg_match("/(\<a.*?login=\"(.*?)\".*?HP=\"(.*?)\"\/\>)/", $Info[1], $Damage)) {
                                                                        if (!preg_match("/\\\$/", $Damage[2])) {
                                                                                if ($Damage[3]>0) {
                                                                                        $Details[$User[1]][3] += $Damage[3];
                                                                                        $DamageCount += $Damage[3];
                                                                                }
                                                                        }
                                                                        $Info[1] = str_replace($Damage[1], '', $Info[1]);
                                                                }
                                                                if (preg_match("/ t=\"7\"/", $Info[1])) {
                                                                        $Details[$User[1]][4] = 1;
                                                                }
                                                        }
                                                }
                                        }
                                        $Turn = preg_replace("/^.*?\/USER./", '', $Turn);
                                }
                        }
                        if (!($DamageCount)) {
                                return array($BattleID, $BattleID, $BattleDate);
                        }
                        sort($Users);
                        $UsersLine = ''; $KeyLine = ''; $Summ = array(); $Summ[] = ''; $Summ[] = '';
                        foreach ($Users as $User) {
                                $KeyLine .= $User;
                                if ($Details[$User][4]) {
                                        $Summ[0] += $Details[$User][0];
                                        $UsersLine .= $User . ',' . $Details[$User][0] . ',' . $Details[$User][1] . ',' . $Details[$User][2] . ',' . $Details[$User][3] . ',0,' . $Details[$User][5] . ',' . $Details[$User][6] . ';';
                                } else {
                                        $Summ[1] += $Details[$User][0];
                                        $UsersLine .= $User . ',' . $Details[$User][0] . ',' . $Details[$User][1] . ',' . $Details[$User][2] . ',' . $Details[$User][3] . ',1,' . $Details[$User][5] . ',' . $Details[$User][6] . ';';
                                }
                        }
                        if ($Summ[0] && $Summ[1]) {
                                $k = ($Summ[0] - $Summ[1])/($Summ[0] + $Summ[1]);
                        } else {
                                $k = 0;
                        }
                        return array($BattleID, $BattleID, $BattleDate);
                } else {
                        return 0;
                }
        }
?>